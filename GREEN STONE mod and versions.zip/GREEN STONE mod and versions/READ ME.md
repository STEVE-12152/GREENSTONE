### ***THIS GUIDE IS FOR ENGLISH USERS:***



1\) Press Win + R to open the "Run" window. (On other operating systems, open the equivalent file explorer.)  

&#x20;  Type %appdata%\\.minecraft and press Enter.



2\) Open the "mods" folder and place the mod’s .jar file inside.



3\) In this mod’s folder, double-click the included NeoForge installer .jar file.  

&#x20;  Select "Install Client" and continue. (The rest will install automatically. Once finished, you can close the window.)



4\) Restart your launcher and select the correct version (NeoForge 1.21.4, which you just installed).  

&#x20;  Then start the game.



5\) Create a new world and enjoy the mod!



