### ***BU TÜRKÇE KULLANICILAR İÇİNDİR:***



1\) Win + R tuşlarına basarak "Çalıştır" penceresini açın. (Başka işletim sistemi kullanıyorsanız, kendi yönteminizle açın.)  

&#x20;  %appdata%\\.minecraft yazıp Enter’a basın.



2\) Açılan klasörde "mods" klasörünü bulun ve modun .jar dosyasını içine kopyalayın.



3\) Bu modun klasöründe bulunan NeoForge yükleme .jar dosyasına çift tıklayın.  

&#x20;  "Install Client" seçeneğine basın ve kurulumu tamamlayın. (Kurulum bitince pencereyi kapatabilirsiniz.)



4\) Launcher’inizi yeniden başlatın ve doğru sürümü seçin (az önce kurduğunuz NeoForge 1.21.4 sürümü).  

&#x20;  Ardından oyunu başlatın.



5\) Yeni bir dünya açın ve modun keyfini çıkarın!



